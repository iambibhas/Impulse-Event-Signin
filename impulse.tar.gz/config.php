<?php
/*
 *      config.php
 *
 */

define('DB_HOST', 'localhost');
define('DB_UNAME', 'root'); //Username you use to login to phpmyadmin
define('DB_PASSWD', 'toor'); //password for the same
define('DB_NAME', 'impulse'); //database name
?>
